package com.callicoder.goparking.exceptions;

public class InvalidParameterException extends Exception {
    public InvalidParameterException(String message) {
        super(message);
    }
}
